import VendorPanel from "@/components/VendorPanel";

export default function VendedoresPage() {
  return <VendorPanel />;
}
