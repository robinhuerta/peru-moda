"use client";

import { useState } from "react";
import {
  LayoutGrid,
  Package,
  ShoppingBag,
  MessageSquare,
  Settings,
  Plus,
  X,
  Search,
  Star,
  TrendingUp,
  ChevronRight,
  ImagePlus,
} from "lucide-react";

const NAV_ITEMS = [
  { id: "resumen", label: "Resumen", icon: LayoutGrid },
  { id: "productos", label: "Productos", icon: Package },
  { id: "pedidos", label: "Pedidos", icon: ShoppingBag },
  { id: "mensajes", label: "Mensajes", icon: MessageSquare },
  { id: "config", label: "Configuración", icon: Settings },
];

const PRODUCTOS_INICIALES = [
  { id: 1, nombre: "Snapback Lima Trap", tipo: "Snapback", precio: 89, stock: 14, estado: "Activo" },
  { id: 2, nombre: "Dad Hat Andina Beige", tipo: "Dad Hat", precio: 65, stock: 3, estado: "Activo" },
  { id: 3, nombre: "Trucker Costa Verde", tipo: "Trucker", precio: 72, stock: 0, estado: "Agotado" },
  { id: 4, nombre: "Bucket Selva Bordado", tipo: "Bucket", precio: 78, stock: 9, estado: "Pausado" },
  { id: 5, nombre: "Beisbolera Cusco Gold", tipo: "Beisbolera", precio: 95, stock: 21, estado: "Activo" },
];

const PEDIDOS = [
  { id: "PM-1042", comprador: "Diego R.", producto: "Snapback Lima Trap", total: 89, estado: "Por enviar" },
  { id: "PM-1041", comprador: "Camila V.", producto: "Beisbolera Cusco Gold", total: 190, estado: "Enviado" },
  { id: "PM-1039", comprador: "Jhonny A.", producto: "Dad Hat Andina Beige", total: 65, estado: "Entregado" },
  { id: "PM-1035", comprador: "Fabiola Q.", producto: "Bucket Selva Bordado", total: 78, estado: "Por enviar" },
];

const ESTADO_COLOR = {
  Activo: "var(--accent-green)",
  Agotado: "var(--accent-red)",
  Pausado: "var(--accent-gold)",
  "Por enviar": "var(--accent-gold)",
  Enviado: "#7CA8D6",
  Entregado: "var(--accent-green)",
};

function TagCard({ label, value, hint, icon: Icon }) {
  return (
    <div className="tag-card relative p-5 flex flex-col gap-2">
      <span className="tag-hole" />
      <div className="flex items-center justify-between">
        <span className="uppercase tracking-widest text-[11px] font-mono" style={{ color: "var(--text-muted)" }}>
          {label}
        </span>
        <Icon size={16} style={{ color: "var(--accent-gold)" }} />
      </div>
      <span className="font-display text-3xl leading-none" style={{ color: "var(--text)" }}>
        {value}
      </span>
      <span className="text-xs font-mono" style={{ color: "var(--text-muted)" }}>
        {hint}
      </span>
    </div>
  );
}

function Pill({ text }) {
  const color = ESTADO_COLOR[text] || "var(--text-muted)";
  return (
    <span
      className="inline-flex items-center gap-1.5 text-[11px] font-mono uppercase tracking-wide px-2.5 py-1 rounded-full border"
      style={{ borderColor: color, color }}
    >
      <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: color }} />
      {text}
    </span>
  );
}

export default function VendorPanel() {
  const [activeNav, setActiveNav] = useState("productos");
  const [productos, setProductos] = useState(PRODUCTOS_INICIALES);
  const [showForm, setShowForm] = useState(false);
  const [search, setSearch] = useState("");
  const [form, setForm] = useState({ nombre: "", tipo: "Snapback", color: "", talla: "Única", precio: "", stock: "" });

  const filtrados = productos.filter((p) => p.nombre.toLowerCase().includes(search.toLowerCase()));

  function handlePublicar(e) {
    e.preventDefault();
    if (!form.nombre || !form.precio) return;
    setProductos((prev) => [
      { id: Date.now(), nombre: form.nombre, tipo: form.tipo, precio: Number(form.precio) || 0, stock: Number(form.stock) || 0, estado: "Activo" },
      ...prev,
    ]);
    setForm({ nombre: "", tipo: "Snapback", color: "", talla: "Única", precio: "", stock: "" });
    setShowForm(false);
  }

  return (
    <div className="w-full min-h-[700px] flex" style={{ background: "var(--bg)", fontFamily: "var(--font-body)" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Oswald:wght@500;600;700&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap');
        :root {
          --bg: #14120F;
          --surface: #1D1A16;
          --surface-2: #262119;
          --border: #362F26;
          --text: #F3EEE5;
          --text-muted: #A69C8C;
          --accent-red: #D6402A;
          --accent-gold: #E3A93D;
          --accent-green: #5C9A6E;
        }
        .font-display { font-family: 'Oswald', sans-serif; text-transform: uppercase; letter-spacing: 0.02em; }
        .tag-card {
          background: var(--surface);
          border: 1px dashed var(--border);
          border-radius: 4px;
        }
        .tag-hole {
          position: absolute;
          top: -1px;
          left: 16px;
          width: 10px;
          height: 10px;
          border-radius: 50%;
          background: var(--bg);
          border: 1px dashed var(--border);
        }
        .nav-item { transition: color .15s ease, background-color .15s ease; }
        .nav-item:hover { background: var(--surface-2); color: var(--text); }
        .nav-item.active { background: var(--surface-2); color: var(--accent-gold); }
        .btn-primary { background: var(--accent-red); color: #F3EEE5; }
        .btn-primary:hover { filter: brightness(1.08); }
        .stitch { border-top: 1px dashed var(--border); }
        input, select { background: var(--surface-2); color: var(--text); border: 1px solid var(--border); }
        input::placeholder { color: var(--text-muted); }
        input:focus, select:focus { outline: none; border-color: var(--accent-gold); }
        ::-webkit-scrollbar { width: 8px; height: 8px; }
        ::-webkit-scrollbar-thumb { background: var(--border); border-radius: 4px; }
      `}</style>

      {/* Sidebar */}
      <aside className="w-[220px] shrink-0 flex flex-col" style={{ background: "var(--surface)", borderRight: "1px solid var(--border)" }}>
        <div className="px-5 py-6" style={{ borderBottom: "1px solid var(--border)" }}>
          <p className="font-display text-lg" style={{ color: "var(--text)" }}>
            Perú <span style={{ color: "var(--accent-red)" }}>&</span> Moda
          </p>
          <p className="text-[11px] font-mono mt-0.5" style={{ color: "var(--text-muted)" }}>panel de vendedor</p>
        </div>

        <div className="px-4 py-4 flex items-center gap-3" style={{ borderBottom: "1px solid var(--border)" }}>
          <div
            className="w-9 h-9 rounded-full flex items-center justify-center font-display text-sm"
            style={{ background: "var(--accent-gold)", color: "var(--bg)" }}
          >
            LG
          </div>
          <div className="leading-tight">
            <p className="text-sm" style={{ color: "var(--text)" }}>Lima Gorras SAC</p>
            <p className="flex items-center gap-1 text-[11px] font-mono" style={{ color: "var(--text-muted)" }}>
              <Star size={10} fill="var(--accent-gold)" style={{ color: "var(--accent-gold)" }} /> 4.8 · verificado
            </p>
          </div>
        </div>

        <nav className="flex-1 px-3 py-4 flex flex-col gap-1">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = activeNav === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveNav(item.id)}
                className={`nav-item flex items-center gap-3 px-3 py-2.5 rounded text-sm text-left ${active ? "active" : ""}`}
                style={{ color: active ? "var(--accent-gold)" : "var(--text-muted)" }}
              >
                <Icon size={16} />
                {item.label}
              </button>
            );
          })}
        </nav>
      </aside>

      {/* Main */}
      <main className="flex-1 flex flex-col">
        <header className="flex items-center justify-between px-8 py-6" style={{ borderBottom: "1px solid var(--border)" }}>
          <div>
            <h1 className="font-display text-2xl" style={{ color: "var(--text)" }}>Mis gorras</h1>
            <p className="text-xs font-mono mt-1" style={{ color: "var(--text-muted)" }}>
              {productos.length} publicadas · {productos.filter((p) => p.estado === "Activo").length} activas
            </p>
          </div>
          <button
            onClick={() => setShowForm(true)}
            className="btn-primary flex items-center gap-2 px-4 py-2.5 rounded font-display text-sm"
          >
            <Plus size={16} /> Publicar gorra
          </button>
        </header>

        <div className="px-8 py-6 flex flex-col gap-8 overflow-y-auto">
          {/* Stats como etiquetas colgantes */}
          <div className="grid grid-cols-4 gap-4">
            <TagCard label="Ventas del mes" value="S/ 2,340" hint="+18% vs. anterior" icon={TrendingUp} />
            <TagCard label="Productos activos" value={productos.filter((p) => p.estado === "Activo").length} hint={`${productos.length} en catálogo`} icon={Package} />
            <TagCard label="Pedidos pendientes" value={PEDIDOS.filter((p) => p.estado === "Por enviar").length} hint="por despachar hoy" icon={ShoppingBag} />
            <TagCard label="Calificación" value="4.8" hint="132 reseñas" icon={Star} />
          </div>

          {/* Buscador */}
          <div className="flex items-center gap-2 max-w-sm px-3 py-2 rounded" style={{ background: "var(--surface)", border: "1px solid var(--border)" }}>
            <Search size={15} style={{ color: "var(--text-muted)" }} />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Buscar en tus gorras..."
              className="bg-transparent text-sm w-full outline-none border-none"
            />
          </div>

          {/* Tabla de productos */}
          <div className="rounded overflow-hidden" style={{ border: "1px solid var(--border)" }}>
            <div
              className="grid grid-cols-[2fr_1fr_1fr_1fr_1fr_auto] px-5 py-3 text-[11px] font-mono uppercase tracking-wide"
              style={{ background: "var(--surface-2)", color: "var(--text-muted)" }}
            >
              <span>Producto</span>
              <span>Tipo</span>
              <span>Precio</span>
              <span>Stock</span>
              <span>Estado</span>
              <span></span>
            </div>
            {filtrados.map((p, i) => (
              <div
                key={p.id}
                className={`grid grid-cols-[2fr_1fr_1fr_1fr_1fr_auto] items-center px-5 py-4 text-sm ${i !== 0 ? "stitch" : ""}`}
                style={{ background: "var(--surface)", color: "var(--text)" }}
              >
                <div className="flex items-center gap-3">
                  <div
                    className="w-9 h-9 rounded flex items-center justify-center shrink-0"
                    style={{ background: "var(--surface-2)", border: "1px dashed var(--border)" }}
                  >
                    <ImagePlus size={14} style={{ color: "var(--text-muted)" }} />
                  </div>
                  {p.nombre}
                </div>
                <span style={{ color: "var(--text-muted)" }}>{p.tipo}</span>
                <span className="font-mono">S/ {p.precio}</span>
                <span className="font-mono" style={{ color: p.stock === 0 ? "var(--accent-red)" : "var(--text-muted)" }}>
                  {p.stock}
                </span>
                <Pill text={p.estado} />
                <ChevronRight size={16} style={{ color: "var(--text-muted)" }} />
              </div>
            ))}
            {filtrados.length === 0 && (
              <div className="px-5 py-8 text-center text-sm" style={{ color: "var(--text-muted)" }}>
                No hay gorras que coincidan con "{search}".
              </div>
            )}
          </div>

          {/* Pedidos recientes */}
          <div>
            <h2 className="font-display text-lg mb-3" style={{ color: "var(--text)" }}>Pedidos recientes</h2>
            <div className="rounded overflow-hidden" style={{ border: "1px solid var(--border)" }}>
              {PEDIDOS.map((pedido, i) => (
                <div
                  key={pedido.id}
                  className={`grid grid-cols-[1fr_1.5fr_1.5fr_1fr_1fr] items-center px-5 py-4 text-sm ${i !== 0 ? "stitch" : ""}`}
                  style={{ background: "var(--surface)", color: "var(--text)" }}
                >
                  <span className="font-mono" style={{ color: "var(--text-muted)" }}>{pedido.id}</span>
                  <span>{pedido.comprador}</span>
                  <span style={{ color: "var(--text-muted)" }}>{pedido.producto}</span>
                  <span className="font-mono">S/ {pedido.total}</span>
                  <Pill text={pedido.estado} />
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>

      {/* Modal publicar gorra */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6" style={{ background: "rgba(0,0,0,0.6)" }}>
          <form
            onSubmit={handlePublicar}
            className="w-full max-w-md rounded p-6 flex flex-col gap-4"
            style={{ background: "var(--surface)", border: "1px solid var(--border)" }}
          >
            <div className="flex items-center justify-between">
              <h3 className="font-display text-xl" style={{ color: "var(--text)" }}>Publicar gorra</h3>
              <button type="button" onClick={() => setShowForm(false)} style={{ color: "var(--text-muted)" }}>
                <X size={18} />
              </button>
            </div>

            <div
              className="h-28 rounded flex flex-col items-center justify-center gap-1 cursor-pointer"
              style={{ border: "1px dashed var(--border)", color: "var(--text-muted)" }}
            >
              <ImagePlus size={20} />
              <span className="text-xs font-mono">Subir foto del producto</span>
            </div>

            <input
              placeholder="Nombre de la gorra"
              value={form.nombre}
              onChange={(e) => setForm({ ...form, nombre: e.target.value })}
              className="text-sm rounded px-3 py-2"
            />

            <div className="grid grid-cols-2 gap-3">
              <select
                value={form.tipo}
                onChange={(e) => setForm({ ...form, tipo: e.target.value })}
                className="text-sm rounded px-3 py-2"
              >
                {["Snapback", "Trucker", "Dad Hat", "Beisbolera", "Bucket", "Cuero", "Personalizada"].map((t) => (
                  <option key={t}>{t}</option>
                ))}
              </select>
              <select
                value={form.talla}
                onChange={(e) => setForm({ ...form, talla: e.target.value })}
                className="text-sm rounded px-3 py-2"
              >
                {["Única", "S/M", "L/XL", "Ajustable"].map((t) => (
                  <option key={t}>{t}</option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <input
                placeholder="Precio (S/)"
                type="number"
                value={form.precio}
                onChange={(e) => setForm({ ...form, precio: e.target.value })}
                className="text-sm rounded px-3 py-2"
              />
              <input
                placeholder="Stock"
                type="number"
                value={form.stock}
                onChange={(e) => setForm({ ...form, stock: e.target.value })}
                className="text-sm rounded px-3 py-2"
              />
            </div>

            <button type="submit" className="btn-primary font-display text-sm rounded py-2.5 mt-1">
              Publicar en el marketplace
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
